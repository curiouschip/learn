<!doctype html>

<html>
  <head>
    <title></title>
    <script src='/pip/pipkit.js'></script>
    <style>
        html, body {
            background: #b3b3b3;
            font-family: sans-serif;
            font-size: 20px;
            margin: 0;
            padding: 0;
        }
        
        #app {
          position: absolute;
          top: 0;
          left: 0;
          width: 800px;
          height: 480px;
          overflow: hidden;
        }
        
        body {
            height: 480px;
        }
        
        .tiles {
            position: absolute;
            top: 30px;
            left: 40px;
            right: 0;
            height: 87px;
        }
        
        .tile {
            width: 74px;
            height: 87px;
            float: left;
            margin-right: 15px;
            position: relative;
            background-color: black;
            border-top: 5px solid #b3b3b3;
        }
        
        .tile.is-active {
            border-top-color: black;
        }
        
        .tile:before {
            content: ' ';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url("tile.png");
        }
        
        .prompt {
            position: absolute;
            top: 130px;
            left: 35px;
        }
        
        .slider {
            position: absolute;
            left: 30px;
        }
        
        .slider.is-red {
            top: 190px;
        }
        
        .slider.is-green {
            top: 250px;
        }
        
        .slider.is-blue {
            top: 310px;
        }
        
        .slider-name,
        .slider-down,
        .slider-track,
        .slider-up,
        .slider-value {
            float: left;
            margin-right: 10px;
        }
        
        .slider-name {
            width: 70px;
        }
        
        .slider button {
            height: 47px;
            width: 31px;
        }
        
        .slider-down {
            -webkit-appearance: none;
            background: url("down.png");
            padding: 0;
            border: none;
        }
        
        .slider-track {
            width: 350px;
            background: black;
            height: 47px;
            position: relative;
        }
        
        .slider-handle {
            position: absolute;
            top: 0;
            left: 0;
            height: 47px;
        }
        
        .slider.is-red .slider-handle { background: red }
        .slider.is-green .slider-handle { background: green }
        .slider.is-blue .slider-handle { background: blue }
        
        .slider-up {
            -webkit-appearance: none;
            background: url("up.png");
            padding: 0;
            border: none;
        }
        
        button {
          font-size: 16px;
        }
        
        .preview {
            position: absolute;
            top: 200px;
            left: 600px;
            width: 160px;
            height: 160px;
            border: 1px solid black;
            background: black;
        }
        
        .set-all, .clear, .bounce, .loop, .stop {
            position: absolute;
            top: 400px;
            height: 50px;
        }
        
        .set-all {
            width: 320px;
            left: 30px;
        }
        
        .clear {
            left: 370px;
        }
        
        .bounce {
            left: 470px;
        }
        
        .loop {
            left: 600px;
        }
        
        .stop {
            left: 700px;
        }
        
        
        
    </style>
    <script type='text/javascript'>
        var increment = 1
        var outputScale = 1
        var activeLED = 0
        var sliders = []
        var tiles = null
        var preview = null
        var effectInterval = 100
        var colors = [
            [10, 0, 0],    
            [50, 0, 0],
            [255, 0, 0],
            [50, 0, 0],
            [10, 0, 0],
            [0, 0, 0],
            [0, 0, 0],
            [0, 0, 0]
        ]
        
        var tmpBuffer = [
            [0, 0, 0],    
            [0, 0, 0],
            [0, 0, 0],
            [0, 0, 0],
            [0, 0, 0],
            [0, 0, 0],
            [0, 0, 0],
            [0, 0, 0]
        ]
        
        //
        // Physical LED control
        
        function syncLED(ix) {
            var c = colors[ix]
            var r = Math.floor(c[0] / outputScale)
            var g = Math.floor(c[1] / outputScale)
            var b = Math.floor(c[2] / outputScale)
            pip.leds.setOne(ix, r, g, b);
        }
        
        //
        // Get CSS RGB for LED
        
        function getCSSForLED(ix) {
            var c = colors[ix]
            return 'rgb(' + c[0] + ',' + c[1] + ',' + c[2] + ')'
        }
        
        //
        // UI syncing
        
        function syncTileColor(ix) {
            tiles[ix].style.backgroundColor = getCSSForLED(ix)
        }
        
        function syncPreviewColor() {
            preview.style.backgroundColor = getCSSForLED(activeLED)
        }
        
        function syncSliderColor() {
            sliders[0].setValue(colors[activeLED][0])
            sliders[1].setValue(colors[activeLED][1])
            sliders[2].setValue(colors[activeLED][2])
        }
        
        //
        // Change active LED
        
        function setActiveLED(ix) {
            tiles[activeLED].className = 'tile';
            activeLED = ix
            syncPreviewColor()
            syncSliderColor()
            tiles[activeLED].className = 'tile is-active'
        }
        
        //
        //
        
        function setAllLEDsToActiveColour() {
            var c = colors[activeLED]
            for (var i = 0; i < 8; ++i) {
                if (i != activeLED) {
                    setLEDColor(i, c)
                }
            }
        }
        
        //
        // Set the color of an LED
        
        function setLEDColor(i, c) {
            var r = c[0]
            var g = c[1]
            var b = c[2]
            if (r < 0) r = 0
            if (r > 255) r = 255
            if (g < 0) g = 0
            if (g > 255) g = 255
            if (b < 0) b = 0
            if (b > 255) b = 255
            colors[i][0] = r
            colors[i][1] = g
            colors[i][2] = b
            syncLED(i)
            syncTileColor(i)
            if (i == activeLED) {
                syncPreviewColor()
                syncSliderColor()
            }
        }
        
        //
        //
        
        function setActiveComponent(i, v) {
            var c = colors[activeLED].slice(0)
            c[i] = v
            setLEDColor(activeLED, c)
        }
        
        //
        //
        
        var timer = null;
        
        function start(effect) {
            stop();
            if (effect === 'bounce') {
                var initial = []
                for (var i = 0; i < 5; ++i) {
                    initial.push(colors[i].slice(0))
                }
                var direction = 1
                var step = 2
                timer = setInterval(function() {
                    for (var i = 0; i < 8; ++i) {
                        colors[i][0] = colors[i][1] = colors[i][2] = 0
                    }
                    for (var i = 0; i < 5; ++i) {
                        var target = i + step - 2;
                        if (target < 0 || target >= 8) continue;
                        colors[target][0] = initial[i][0]
                        colors[target][1] = initial[i][1]
                        colors[target][2] = initial[i][2]
                    }
                    if (direction == 1) {
                        step++
                        if (step === 8) {
                            step = 6
                            direction = -1
                        }
                    } else if (direction == -1) {
                        step--
                        if (step < 0) {
                            step = 1
                            direction = 1
                        }
                    }
                    _syncState();        
                }, effectInterval)
            } else if (effect === 'loop') {
                timer = setInterval(function() {
                    for (var i = 1; i < 8; ++i) {
                        tmpBuffer[i][0] = colors[i-1][0];
                        tmpBuffer[i][1] = colors[i-1][1];
                        tmpBuffer[i][2] = colors[i-1][2];
                    }
                    tmpBuffer[0][0] = colors[7][0];
                    tmpBuffer[0][1] = colors[7][1];
                    tmpBuffer[0][2] = colors[7][2];
                    _swap();
                    _syncState();
                }, effectInterval);
            }
            
            function _swap() {
                var c = colors;
                colors = tmpBuffer;
                tmpBuffer = c;
            }
            
            function _syncState() {
                for (var i = 0; i < 8; ++i) {
                    syncLED(i);
                    syncTileColor(i);
                }
                syncPreviewColor();
                syncSliderColor();
            }
        }
        
        function stop() {
            clearInterval(timer);
        }
        
        //
        //
        
        function createSlider(ix, value, el, onChange) {
            var track = el.querySelector('.slider-track');
            var handle = el.querySelector('.slider-handle');
            var number = el.querySelector('.slider-value');
            
            var rect = track.getBoundingClientRect();
            
            var down = el.querySelector('.slider-down')
            down.onclick = function() {
                var curr = colors[activeLED].slice(0)
                curr[ix] = curr[ix] - increment
                setLEDColor(activeLED, curr)
            }
            
            var up = el.querySelector('.slider-up')
            up.onclick = function() {
                var curr = colors[activeLED].slice(0)
                curr[ix] = curr[ix] + increment
                setLEDColor(activeLED, curr)
            }
            
            track.ontouchstart = function(evt) {
                var t = evt.changedTouches[0]
                var id = t.identifier;
                
                _update(t.screenX)
                
                document.addEventListener('touchmove', _move)
                document.addEventListener('touchend', _cancel)
                
                function _update(x) {
                    var o = (x - rect.left) / rect.width
                    var v = Math.floor(o * 255)
                    onChange(ix, v)
                }
                
                function _find(list) {
                    for (var i = 0; i < list.length; ++i) {
                        if (list[i].identifier == id) {
                            return list[i];
                        }
                    }
                    return null
                }
                
                function _move(evt) {
                    var t = _find(evt.changedTouches)
                    if (!t) return
                    document.body.style.backgroundColor = 'red'
                    _update(t.screenX)
                }
                
                function _cancel(evt) {
                    var t = _find(evt.changedTouches)
                    if (!t) return
                    document.removeEventListener('touchmove', _move);
                    document.removeEventListener('touchend', _cancel);
                }
            }
            
            
            function _set(v) {
                value = v
                number.textContent = v
                handle.style.width = ((v / 255) * 100) + '%'
            }
            
            _set(value)
            
            return {
                setValue: _set
            }
        }
        
        
        
        function setupTile(ix, el) {
            el.onclick = function() {
                setActiveLED(ix)
            }
        }
        
        function init() {
            tiles = document.querySelectorAll('.tile')
            for (var i = 0; i < tiles.length; ++i) {
                setupTile(i, tiles[i])
            }
            
            preview = document.querySelector('.preview')
            
            sliders.push(createSlider(0, colors[0][0], document.querySelector('.slider.is-red'), setActiveComponent))
            sliders.push(createSlider(1, colors[0][1], document.querySelector('.slider.is-green'), setActiveComponent))
            sliders.push(createSlider(2, colors[0][2], document.querySelector('.slider.is-blue'), setActiveComponent))
            
            document.querySelector('.set-all').onclick = setAllLEDsToActiveColour;
            document.querySelector('.bounce').onclick = function() { start('bounce') }
            document.querySelector('.loop').onclick = function() { start('loop') }
            document.querySelector('.stop').onclick = stop;
            
            document.querySelector('.clear').onclick = function() {
                for (var i = 0; i < 8; ++i) {
                    colors[i][0] = colors[i][1] = colors[i][2] = 0
                    syncLED(i)
                    syncTileColor(i)
                }
                syncPreviewColor()
                syncSliderColor()
            }
            
            setActiveLED(0)
            for (var i = 0; i < 8; ++i) {
                syncTileColor(i)
                syncLED(i)
            }
        }
    </script>
  </head>
  <body onload='init()'>
     <div id='app'>
  
     <div class='tiles'>
       <div class='tile'></div>
       <div class='tile'></div>
       <div class='tile'></div>
       <div class='tile'></div>
       <div class='tile'></div>
       <div class='tile'></div>
       <div class='tile'></div>
       <div class='tile'></div>
     </div>
     
     <div class='prompt'>
         Select a light, then modify its colour below:
     </div>
     
     <div class='slider is-red'>
         <div class='slider-name' style='color:red'>RED</div>
         <button class='slider-down'></button>
         <div class='slider-track'>
             <div class='slider-handle'></div>
         </div>
         <button class='slider-up'></button>
         <div class='slider-value' style='color:red'>0</div>
     </div>
     
     <div class='slider is-green'>
         <div class='slider-name' style='color:green'>GREEN</div>
         <button class='slider-down'></button>
         <div class='slider-track'>
             <div class='slider-handle'></div>
         </div>
         <button class='slider-up'></button>
         <div class='slider-value' style='color:green'>0</div>
     </div>
     
     <div class='slider is-blue'>
         <div class='slider-name' style='color:blue'>BLUE</div>
         <button class='slider-down'></button>
         <div class='slider-track'>
             <div class='slider-handle'></div>
         </div>
         <button class='slider-up'></button>
         <div class='slider-value' style='color:blue'>0</div>
     </div>
     
     <button class='set-all'>Set all lights to active colour</button>
     <button class='clear'>Clear</button>
     <button class='loop'>Loop</button>
     <button class='bounce'>Bounce</button>
     <button class='stop'>Stop</button>
     
     <div class='preview'></div>
     
     </div>
  </body>
</html>