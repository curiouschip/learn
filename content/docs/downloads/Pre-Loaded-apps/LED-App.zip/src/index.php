<!doctype html>

<html>
  <head>
    <title></title>
    <script src='/pip/pipkit.js'></script>
    
    <style type='text/css'>
      html {
        font: 24px/1.4 Poppins;
      }
      button {
        font-family: Poppins;
	  }
      #app, .screen {
      	position: absolute;
        top: 0;
        left: 0;
        width: 800px;
        height: 480px;
      }
      .screen {
      	display: none;
        background-position: bottom left;
        background-repeat: no-repeat;
      }
      .screen h1 {
        position: absolute;
        top: 10px;
        left: 10px;
        font-size: 26px;
        font-weight: normal;
        margin: 0;
      }
      button.next {
        position: absolute;
        bottom: 16px;
        right: 16px;
      }
      button.skip {
		position: absolute;
        bottom: 16px;
        left: 16px;
      }
      button.rounded {
        position: absolute;
        color: white;
        -webkit-appearance: none;
        border-radius: 10px;
        width: 220px;
        padding: 10px 20px;
        border: none;
      }
        button.roundedgrey {
        position: absolute;
        color: grey;
        -webkit-appearance: none;
        border-radius: 10px;
        width: 220px;
        padding: 10px 20px;
        border: none;
      }
        button.roundedwide {
        position: absolute;
        color: white;
        -webkit-appearance: none;
        border-radius: 10px;
        width: 280px;
        padding: 10px 20px;
        border: none;
      }
          
    </style>
    
    <script type='text/javascript'>
      const onLevel = 18;

      const single = [false, false, false];
      const fade = [
        [false, false, false],
        [false, false, false]
      ];

      function gotoSliders() {
        document.location = '/sliders.php'; 
      }

      function singleToggle(c) {
        single[c] = !single[c];
        pip.leds.setOne(
        	0,
        	single[0] ? onLevel : 0,
        	single[1] ? onLevel : 0,
        	single[2] ? onLevel : 0
        );
      }

      function singleClear() {
        single[0] = single[1] = single[2] = false;
        pip.leds.setOne(0, 0, 0, 0);
      }

      function lerp(start, end, offset) {
        start = start ? onLevel : 0
        end = end ? onLevel : 0
        return start + (end - start) * (offset / 7)
      }

      function setFade(led, comp, on) {
        fade[led][comp] = !fade[led][comp];
        for (let i = 0; i < 8; ++i) {
      	  const r = lerp(fade[0][0], fade[1][0], i);    
          const g = lerp(fade[0][1], fade[1][1], i);
          const b = lerp(fade[0][2], fade[1][2], i);
          pip.leds.setOne(i, r, g, b);
        }
      }

      document.addEventListener('DOMContentLoaded', () => {
        pip.leds.setBrightness(100);
        pip.leds.clear(true);

    let timer;
        
		const screens = document.querySelectorAll('.screen');
        
        runScreen(0);
		
        function runScreen(curr, prev) {
          pip.leds.clear();
          clearInterval(timer);

          if (curr === 1) {
            let offset = 0;
            timer = setInterval(() => {
              pip.leds.setOne(offset, 10, 10, 10);
              setTimeout(() => {
                pip.leds.setOne(offset, 0, 0, 0);
                offset = (offset + 1) % 8;
              }, 100);
            }, 500);
          }
          
          if (typeof prev === 'number') {
            screens[prev].style.display = 'none';
          }
          const root = screens[curr];
          
          root.style.display = 'block';
          
          if (curr === 0) {
            root.querySelector('button.skip').onclick = () => {
              gotoSliders();
            }
          }
          
          root.querySelector('button.next').onclick = () => {
            if (curr === 10) {
              gotoSliders();
            } else {
              runScreen(curr+1, curr); 
            }
          }
        }
      });
    </script>
    
  </head>
  <body>
    <div id='app'>
      <div class='screen'>
        <h1>This simple app allows you to play around with Pip's built-in LEDs. <br><br>There is a short tutorial showing you how LEDs work in general, which you can view by clicking the button below.<br><br>When exiting the app, please make sure to press the CLEAR button to turn the LEDs off, as leaving them on will drain your battery faster.</h1>
        <button class='next'>Tutorial &gt;</button>
		<button class='skip'>Go to App</button>
      </div>
      <div class='screen' style='background-image:url("screen1.png"); background-position: 180px 110px'>
        <h1>Pip has 8 lights above the screen, called Light Emitting Diodes (shortened to LEDs).</h1>
        <button class='next'>Next &gt;</button>
      </div>
      <div class='screen' style='background-image:url("LEDflash.gif"); background-position: 250px 120px'>
        <h1>Within each LED, there is a tiny Red, Green, and Blue light, along with a controller chip. We refer to these kinds of lights as RGB LEDs.</h1>
        <button class='next'>Next &gt;</button>
      </div>
      <div class='screen' style='background-image:url("secondary.png"); background-position: 10px 140px'>
        <h1>Red, Green and Blue are known as the PRIMARY colours and can be mixed together to make SECONDARY colours. Mixing Red, Green and Blue produces White.</h1>
        <button class='next'>Next &gt;</button>
      </div>
      <div class='screen'>
        <h1>We use a combination of 3 numbers to represent the levels of Red, Green and Blue present. The values range from 0 (off), to 255 (full brightness). Click the buttons below to light up the LEDs.</h1>
		<button class='rounded' onclick='pip.leds.setOne(0, 10, 0, 0)' style='background-color: red; left: 30px; top: 160px'>255,0,0</button>
        <button class='rounded' onclick='pip.leds.setOne(1, 0, 10, 0)' style='background-color: green; left: 290px; top: 160px'>0,255,0</button>
        <button class='rounded' onclick='pip.leds.setOne(2, 0, 0, 30)' style='background-color: blue; left: 550px; top: 160px'>0,0,255</button>
        <button class='roundedgrey' onclick='pip.leds.setOne(3, 10, 10, 0)' style='background-color: yellow; left: 30px; top: 270px'>255,255,0</button>
        <button class='roundedgrey' onclick='pip.leds.setOne(4, 0, 10, 10)' style='background-color: cyan; left: 290px; top: 270px'>0,255,255</button>
        <button class='rounded' onclick='pip.leds.setOne(5, 10, 0, 10)' style='background-color: magenta; left: 550px; top: 270px'>255,0,255</button>
        <button class='roundedwide' onclick='pip.leds.setOne(6, 50, 50, 50)' style='background-color: grey; left: 30px; top: 380px'>255,255,255</button>
        <button class='next'>Next &gt;</button>
      </div>
      <div class='screen'>
        <h1>By controlling the brightness levels of Red, Green and Blue, we can make any colour we want. Click the buttons below to see how we control the brightness. The first LED is set to (0,0,0) and the last LED is set to the colour you select below.</h1>
		<button class='rounded' onclick='setFade(1, 0)' style='background-color: red; left: 30px; top: 220px'>255,0,0</button>
        <button class='rounded' onclick='setFade(1, 1)' style='background-color: green; left: 290px; top: 220px'>0,255,0</button>
        <button class='rounded' onclick='setFade(1, 2)' style='background-color: blue; left: 550px; top: 220px'>0,0,255</button>
        <button class='next'>Next &gt;</button>
      </div>
      <div class='screen'>
        <h1>Mixing Red, Green and Blue at different brightness levels allows for over 16 million colours to be made. Set the first and last LED colours above and Pip will do the rest.</h1>
        <h2 style='position: absolute; left: 95px; top: 100px'>LED 1</h2>
		<button class='rounded' onclick='setFade(0, 0)' style='background-color: red; left: 30px; top: 200px'>RED</button>
        <button class='rounded' onclick='setFade(0, 1)' style='background-color: green; left: 30px; top: 280px'>GREEN</button>
        <button class='rounded' onclick='setFade(0, 2)' style='background-color: blue; left: 30px; top: 360px'>BLUE</button>

        <h2 style='position: absolute; left: 420px; top: 100px'>LED 8</h2>
		<button class='rounded' onclick='setFade(1, 0)' style='background-color: red; left: 360px; top: 200px'>RED</button>
        <button class='rounded' onclick='setFade(1, 1)' style='background-color: green; left: 360px; top: 280px'>GREEN</button>
        <button class='rounded' onclick='setFade(1, 2)' style='background-color: blue; left: 360px; top: 360px'>BLUE</button>

        <button class='next'>Next &gt;</button>
      </div>
      <div class='screen' style='background-image:url("screen6.png");'>
        <h1>There are 256 levels of brightness for each of the primary colours (0 - 255), allowing us to make 256 x 256 x 256, or 16,777,216 colours. Our eyes have Red, Green and Blue cones, each of which can register around 100 different colour shades allowing us to see around 1 million different colours.</h1>
        <button class='next'>Next &gt;</button>
      </div>
      <div class='screen' style='background-image:url("screen7.png");'>
        <h1>Our TVs have tiny picture elements (known as pixels) that make up the screen and each pixel has a Red, Green, and Blue element. Each lights up at different levels of brightness to show the full range of colours.</h1>
        <button class='next'>Next &gt;</button>
      </div>
      <div class='screen' style='background-image:url("cheetahTV.gif"); background-position: 40px 160px'>
        <h1>On a 4k resolution TV, there are 7,516,800 pixels (3480 x 2160). Each one changes it's colour at least 60 times a second in order to show a moving image.</h1>
        <button class='next'>Next &gt;</button>
      </div>
      <div class='screen' style='background-image:url("dance.gif"); background-position: 200px 100px'>
        <h1>Pip's screen is much smaller, but still has 384,000 pixels, changing 60 times a second. Click 'Next' to launch the app.</h1>
        <button class='next'>Next &gt;</button>
      </div>
    </div>
  </body>
</html>
