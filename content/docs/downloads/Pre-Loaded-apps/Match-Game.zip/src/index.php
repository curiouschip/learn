<!doctype html>

<html>
  <head>
    <title>Game</title>
    <script type='text/javascript' src='/pip/pipkit.js'></script>
    <style type='text/css'>
      html, body {
        overflow: hidden;
      }
      body {
        margin: 0;
        padding: 0;
        font: 30px sans-serif;
      }
      .app {
        position: absolute;
        top: 0;
        left: 0;
        width: 800px;
        height: 480px;
        background: #fff;
      }
      #intro {
        margin: 20px;
        padding: 20px;
        font: 30px sans-serif;
      }
      #start {
        position: absolute;
        top: 240px;
        left: 190px;
        width: 400px;
        height: 100px;
        font-size: 36px;
        font-weight: bold;
        box-sizing: border-box;
      }
      .timer {
        position: absolute;
        top: 20px;
        right: 60px;
        text-align: right;
        font-family: monospace;
        color: red;
        font-size: 64px;
        font-weight: bold;
      }
      .image {
        position: absolute;
        bottom: 0px;
        left: 20px;
      }
      .win, .lose {
        position: absolute;
        top: 30px;
        left: 0;
        width: 100%;
        text-align: center;
        color: green;
        font-size: 56px;
        line-height: 56px;
        margin: 0;
        padding: 0;
      }
      .lose {
        color: red;
      }
    </style>
    <script>
      // 'up' or 'down'
      var Mode = 'down';
      
      var GameTime = 5;

      var PadImages = [
        ['1p.png', '1p-s.png', '1p-t.png'],
        ['2p.png', '2p-s.png', '2p-t.png'],
        ['5p.png', '5p-s.png', '5p-t.png'],
        ['10p.png', '10p-s.png', '10p-t.png'],
        ['20p.png', '20p-s.png', '20p-t.png'],
        ['50p.png', '50p-s.png', '50p-t.png'],
        ['100p.png', '100p-s.png', '100p-t.png'],
        ['200p.png', '200p-s.png', '200p-t.png']
      ];
/*
      var PadImages = [
        '1p-t.png',
        '2p-t.png',
        '5p-t.png',
        '10p-t.png',
        '20p-t.png',
        '50p-t.png',
        '100p-t.png',
        '200p-t.png'
      ];
*/

      var ui;

      function start(cb) {
        var item = Math.floor(Math.random() * 8);
        console.log("item: " + item);
          
        var images = PadImages[item];
        var index = Math.floor(Math.random() * images.length);
       
        ui.image.src = images[index];
        ui.image.style.display = '';

        var clock;
        var startTime = Date.now();
        var won = false;
        var over = false;
        var timerExpired = false;

        if (Mode === 'up') {
          clock = setInterval(function() {
            var dt = (Date.now() - startTime) / 1000;
            setTime(dt);
          }, 10);
        } else {
          clock = setInterval(function() {
            var dt = (Date.now() - startTime) / 1000;
            var remain = GameTime - dt;
            if (remain < 0) {
              remain = 0;
              over = true;
            }
            setTime(remain);
            if (over) {
              clearInterval(clock);
              ui.lose.style.display = '';
              next();
            }
          }, 10);
        }

        getInput(onPress, onRelease);

        function onPress(button) {
          if (over) return false;

          clearInterval(clock);
          if (button === item && !timerExpired) {
            ui.win.style.display = '';
          } else {
            ui.lose.style.display = '';
            over = true;
          }
        }

        function onRelease(button) {
          next();
        }

        function next() {
          setTimeout(function() {
            ui.win.style.display = 'none';
            ui.lose.style.display = 'none';
            ui.image.style.display = 'none';
            ui.timer.textContent = '';
            if (over) {
              cb();
            } else {
              start(cb);
            }
          }, 2000);
        }
      }

      function setTime(t) {
        ui.timer.textContent = Math.floor(t) + '.' + (Math.floor(t * 10) % 10);
      }

      function getKeyboardInput(p, r) {
        var curr = null;

        document.body.addEventListener('keydown', down, true);
        document.body.addEventListener('keyup', up, true);
        function down(evt) {
          if (curr === null) {
            if (evt.which >= 49 && evt.which <= 56) {
              curr = evt.which;
              p(evt.which - 49);
            }
          }
        }
        function up(evt) {
          if (curr !== null && evt.which === curr) {
            document.body.removeEventListener('keydown', down, true);
            document.body.removeEventListener('keyup', up, true);
            curr = null;
            r(evt.which - 49);
          }
        }
      }

      function getInput(onPress, onRelease) {
        getKeyboardInput(onPress, onRelease);
      }

      function init() {
        ui = {
          start: document.querySelector('#start'),
          timer: document.querySelector('.timer'),
          image: document.querySelector('.image'),
          win: document.querySelector('.win'),
          lose: document.querySelector('.lose')
        }
        ui.start.onclick = function() {
          ui.start.style.display = 'none';
          start(function() {
            ui.start.style.display = '';
          });
        };
      }
    </script>
  </head>
  <body onload='init()'>
    <div class='app'>
      <p id='intro'>Let's play a simple coin matching game.</p>
      <p id='intro'>Attach your Capacitive Touch board and coins to Pip and press the start button.</p>
      <button id='start'>Start</button>
      <img class='image' src='' style='display:none'>
      <div class='timer'></div>
      <h1 class='win' style='display:none'>Correct!</h1>
      <h1 class='lose' style='display:none'>Game Over!</h1>
    </div>
  </body>
</html>