Items = {
	'drum0',
	'drum1',
	'drum2',
	'drum3',
	'drum4',
	'drum5',
	'drum6',
	'drum7'
}

UseTimer = true
ShowNoteTime = 0.1
ShowGapTime = 0.2
ActiveSeconds = 0.3

---
---
---

Seq = {}
Active = {}
Images = {}
ImagesActive = {}
Sounds = {}
ButtonRects = {
	{0,324,259,156},
	{0,216,216,108},
	{  0,0,216,216},
	{216,0,139,325},
	{259,325,202,155},
	{355,0,164,325},
	{519,0,281,325},
	{461,325,339,155},
}

for i, item in ipairs(Items) do
	Active[i] = 0
	Images[i] = love.graphics.newImage('assets/' .. item .. '.png')
	ImagesActive[i] = love.graphics.newImage('assets/' .. item .. '_active.png')
	Sounds[i] = love.audio.newSource('assets/' .. item .. '.wav', 'static')
end

font = love.graphics.newFont("assets/font.ttf", 32)
love.graphics.setFont(font)

currentState = 'intro'
stateVars = {}
timeInState = 0
guessProgress = 1

function setState(newState)
	currentState = newState
	stateVars = {}
	timeInState = 0
	if States[newState].enter then
		States[newState].enter(stateVars)
	end
end

States = {
	intro = {
		touch = function(x, y)
			Seq = {}
			addRandomNoteToSequence()
			setState('showWait')
		end,
		update = function(dt, vars)
			-- nothing
		end,
		draw = function(vars)
			love.graphics.setColor(0.0, 0.0, 1.0, 1)
			love.graphics.rectangle("fill", 0, 0, 800, 480)
			love.graphics.setColor(1.0, 1.0, 0.0, 1)
			love.graphics.printf("Tap to start!", 0, 100, 800, 'center')
			love.graphics.printf("Repeat the sequence\nshown on the screen\nusing the touchscreen\nor cap touch board", 0, 200, 800, 'center')
		end
	},
	showWait = {
		update = function(dt, vars)
			if timeInState >= 1 then
				setState('showSequence')
			end
		end,
		draw = function(vars)
			drawInstruments()
		end
	},
	showSequence = {
		enter = function(vars)
			vars.index = 1
			vars.s = true
			vars.p = 0
			vars.e = ShowNoteTime
			playNoteAtSequenceIndex(1)
		end,
		update = function(dt, vars)
			vars.p = vars.p + dt
			if vars.p >= vars.e then
				if vars.s then
					vars.s = false
					vars.p = 0
					vars.e = ShowGapTime
				else
					vars.s = true
					vars.index = vars.index + 1
					if vars.index > table.getn(Seq) then
						setState('enterSequence')
					else
						vars.p = 0
						vars.e = ShowNoteTime
						playNoteAtSequenceIndex(vars.index)
					end
				end
			end
		end,
		draw = function(vars)
			drawInstruments()
		end
	},
	enterSequence = {
		enter = function(vars)
			guessProgress = 1
		end,
		touch = function(x, y)
			note = getNoteForXY(x, y)
			if note > 0 then
				doGuess(note)
			end
		end,
		keypress = function(key, scancode)
			note = getNoteForKey(key)
			if note > 0 then
				doGuess(note)
			end
		end,
		update = function(dt, vars)
			
		end,
		draw = function(vars)
			drawInstruments()
			love.graphics.setColor(1.0, 0.0, 0.0, 1)
			love.graphics.print("Play note " .. tostring(guessProgress), 15, 30)
		end
	},
	win = {
		enter = function(vars)
		    addRandomNoteToSequence()
			vars.duration = 2.0
		end,
		update = function(dt, vars)
			if timeInState > vars.duration then
				setState('showWait')
			end
		end,
		draw = function(vars)
			love.graphics.setColor(0.0, 0.0, 1.0, 1)
			love.graphics.rectangle("fill", 0, 0, 800, 480)
			love.graphics.setColor(0.0, 1.0, 0.0, 1)
			love.graphics.printf("WIN!", 0, 220, 800, 'center')
		end
	},
	gameOver = {
		update = function(dt, vars)
			if timeInState > 3 then
				setState('intro')
			end
		end,
		draw = function(vars)
			love.graphics.setColor(1.0, 0.0, 0.0, 1)
			love.graphics.rectangle("fill", 0, 0, 800, 480)
			love.graphics.setColor(1.0, 1.0, 0.0, 1)
			love.graphics.printf("GAME OVER!", 0, 200, 800, 'center')
			love.graphics.printf("SCORE: " .. table.getn(Seq)-1, 0, 240, 800, 'center')
		end
	}
}

function doGuess(guess)
	if guess < 1 or guess > 8 then
		return
	end
	playNote(guess)
	if guess == Seq[guessProgress] then
		guessProgress = guessProgress + 1
		if guessProgress > table.getn(Seq) then
			setState('win')
		end
	else
		setState('gameOver')
	end	
end

function addRandomNoteToSequence()
	v = love.math.random(table.getn(Items))
	table.insert(Seq, v)
end

--
--
--

function love.load()
    love.mouse.setVisible(false)
end

function love.update(dt)
	for i, k in ipairs(Active) do
		Active[i] = Active[i] - dt
	end
	timeInState = timeInState + dt
	States[currentState]["update"](dt, stateVars)
end

function love.draw()
  	States[currentState]["draw"](stateVars)
end

function love.keypressed(key, scancode, isRepeat)
	if isRepeat then
		return
	end
	hnd = States[currentState].keypress
	if hnd then
		hnd(key, scancode)
	end
end

function love.touchpressed(id, x, y, dx, dy, pressure)
	hnd = States[currentState].touch
	if hnd then
		hnd(x, y)
	end
end

function drawInstruments()
	love.graphics.setColor(1.0, 1.0, 1.0, 1)
	for i, rect in ipairs(ButtonRects) do
		img = Images[i]
		if Active[i] > 0 then
			img = ImagesActive[i]
		end
		love.graphics.draw(img, rect[1], rect[2], 0, 1, 1)	
	end	
end

function playNoteAtSequenceIndex(i)
	playNote(Seq[i])
end

function playNote(n)
	if n <= 0 then
		return
	end
	Sounds[n]:stop()
	Sounds[n]:play()
	Active[n] = ActiveSeconds
end

function getNoteForKey(key)
	note = string.byte(key) - string.byte("1") + 1
	if note >= 1 and note <= table.getn(Items) then
		return note
	end
	return -1
end

function getNoteForXY(x, y)
	for i, rect in ipairs(ButtonRects) do
		if x >= rect[1] and x < (rect[1] + rect[3]) and y >= rect[2] and y < (rect[2] + rect[4]) then
			return i
		end
	end
	return -1
end