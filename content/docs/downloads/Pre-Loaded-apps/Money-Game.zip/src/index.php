<!doctype html>

<html>
  <head>
    <title></title>
    <style type='text/css'>
        html, body {
            overflow: hidden;
        }
        body {
            font: 30px sans-serif;
        }
        p {
            margin: 0;
            padding: 0;
        }
        .coin { position: absolute; bottom: 0; }
        .coin:nth-child(1) { left: 30px; }
        .coin:nth-child(2) { left: 60px; }
        .coin:nth-child(3) { left: 90px; }
        .coin:nth-child(4) { left: 120px; }
        .coin:nth-child(5) { left: 150px; }
        .coin:nth-child(6) { left: 180px; }
        .coin:nth-child(7) { left: 210px; }
        .coin:nth-child(8) { left: 240px; }
        #intro {
            box-sizing: border-box;
            padding: 20px;
            margin: 20px;
            background: white;
            position: absolute;
            top: 0;
            left: 0;
            width: 800px;
            height: 480px;
            z-index: 100;
        }
        #intro button {
            position: absolute;
            top: 250px;
            left: 190px;
            width: 400px;
            height: 100px;
            font-size: 36px;
            font-weight: bold;
            box-sizing: border-box;
        }
    </style>
    <script>
        var Games = [
            [2000, 1280, "bg.png"],
            [500, 120, "bg.png"],
            [500, 495, "bike.png"],
            [10000, 9700, "bike.png"],
            [1500, 1183, "lego.png"],
            [2500, 2199, "spade.png"],
            [100, 68, "sweets.png"],
            [1000, 829, "rubik.png"],
            [200, 134, "sweets.png"],
            [400, 344, "minion.png"],
            [700, 612, "minion.png"],
            [1000, 233, "rubik.png"]
        ];

        var PadAmounts = [1, 2, 5, 10, 20, 50, 100, 200];
        
        var target, total
        
        function formatMoney(v) {
            return Math.floor(v / 100) + '.' + ('0' + (v % 100)).substr(-2, 2)
        }
        
        function clearCoins() {
            document.querySelector('.coins').innerHTML = '';
            document.querySelector('.total').innerHTML = formatMoney(0);
            total = 0
        }
        
        function playRandomGame(cb) {
            var g = Games[Math.floor(Math.random() * Games.length)]
            document.getElementById('background').src = g[2]
            playGame(g[0], g[1], cb)
        }
        
        function playGame(money, cost, cb) {
            clearCoins()
            target = money - cost
            document.querySelector('.money').textContent = formatMoney(money)
            document.querySelector('.cost').textContent = formatMoney(cost)
            
            function _getNextCoin() {
                getInput(function(val) {
                    document.querySelector('.coins').innerHTML += "<img class='coin' src='" + val + "p.png'>"
                    total += val
                    document.querySelector('.total').innerHTML = formatMoney(total);
                    if (total == target) {
                        var el = document.querySelector('.win')
                        setTimeout(function() {
                            el.style.display = ''
                            setTimeout(function() {
                                el.style.display = 'none'
                                cb()
                            }, 2000)
                        }, 1000)
                        
                    } else {
                        _getNextCoin()
                    }
                })
            }
            
            _getNextCoin()
        }
        
        function getInput(cb) {
            document.body.onkeydown = (evt) => {
                if (evt.which < 49 || evt.which > 56) {
                    return;
                }
                cb(PadAmounts[evt.which - 49]);
            };
        }
        
        function run() {
            document.querySelector('#intro').style.display = 'none';
            
            document.querySelector('.clear').onclick = function() {
                clearCoins()
            }
            
            function go() {
                playRandomGame(go)
            }
            
            go()
        }
    </script>
  </head>
  <body>
    <img id='background' src='blank.png' style='position: absolute, top: 0; left: 0'>
    <p style='position: absolute; top: 20px; left: 20px'>
      How much change do you get from &pound;<span class='money'></span><br>
      if your items cost &pound;<span class='cost'></span>?
    </p>
    <p style='position:absolute; right: 30px; top: 130px;font-weight: bold; font-size: 40px; text-align: right'>&pound;<span class='total'></span></p>
    <div class='coins' style='position: absolute; bottom: 30px; left: 410px; height: 200px; width: 270px'>
        <img src='1p.png' class='coin'>
        <img src='2p.png' class='coin'>
        <img src='5p.png' class='coin'>
        <img src='10p.png' class='coin'>
        <img src='20p.png' class='coin'>
        <img src='50p.png' class='coin'>
        <img src='100p.png' class='coin'>
        <img src='200p.png' class='coin'>
    </div>
    <button class='clear' style='position:absolute; right: 30px; height: 80px; width: 200px; top: 50%; margin-top: -40px'>Clear</button>
    <img src='win.png' style='position:absolute;top:0;left:0;display:none' class='win'>
    <div id='intro'>
        <p>Let's solve some simple maths problems.</p></br>
        <p>Attach your Capacitive Touch board and coins to Pip and press the start button.</p>
      <button onclick='run();'>Start!</button>    
    </div>
  </body>
</html>