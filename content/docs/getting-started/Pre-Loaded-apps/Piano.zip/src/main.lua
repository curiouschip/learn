Items = {
	'note_0',
	'note_1',
	'note_2',
	'note_3',
	'note_4',
	'note_5',
	'note_6',
	'note_7'
}

ActiveSeconds = 0.3
Active = {}
Images = {}
ImagesActive = {}
Sounds = {}
ButtonRects = {
	{  0,0,100,480},
	{100,0,100,480},
	{200,0,100,480},
	{300,0,100,480},
	{400,0,100,480},
	{500,0,100,480},
	{600,0,100,480},
	{700,0,100,480},
}

for i, item in ipairs(Items) do
	Active[i] = 0
	Images[i] = love.graphics.newImage('assets/' .. item .. '.png')
	ImagesActive[i] = love.graphics.newImage('assets/' .. item .. '_active.png')
	Sounds[i] = love.audio.newSource('assets/' .. item .. '.mp3', 'static')
end

function love.load()
    love.mouse.setVisible(false)
end

function love.update(dt)
	for i, k in ipairs(Active) do
		Active[i] = Active[i] - dt
	end
end

function love.draw()
    drawInstruments()
end

function love.keypressed(key, scancode, isRepeat)
	if isRepeat then
		return
	end
	note = getNoteForKey(key)
	if note > 0 then
		playNote(note)
	end
end

function love.touchpressed(id, x, y, dx, dy, pressure)
	note = getNoteForXY(x, y)
	if note > 0 then
		playNote(note)
	end
end

function drawInstruments()
	love.graphics.setColor(1.0, 1.0, 1.0, 1)
	for i, rect in ipairs(ButtonRects) do
		img = Images[i]
		if Active[i] > 0 then
			img = ImagesActive[i]
		end
		love.graphics.draw(img, rect[1], rect[2], 0, 1, 1)	
	end	
end

function playNote(n)
	if n <= 0 then
		return
	end
	Sounds[n]:stop()
	Sounds[n]:play()
	Active[n] = ActiveSeconds
end

function getNoteForKey(key)
	note = string.byte(key) - string.byte("1") + 1
	if note >= 1 and note <= table.getn(Items) then
		return note
	end
	return -1
end

function getNoteForXY(x, y)
	for i, rect in ipairs(ButtonRects) do
		if x >= rect[1] and x < (rect[1] + rect[3]) and y >= rect[2] and y < (rect[2] + rect[4]) then
			return i
		end
	end
	return -1
end