<!doctype html>

<html>
  <head>
    <title></title>
    <script type='text/javascript' src='/pip/pipkit.js'></script>
    <style type='text/css'>
      html, body {
          margin: 0;
          padding: 0;
      }
      h1 {
          position: absolute;
          top: 20px;
          left: 0;
          width: 100%;
          text-align: center;
          font-family: Helvetica, Arial, sans-serif;
          font-weight: bold;
          font-size: 48px;
          margin: 0;
          padding: 0;
          color: white;
      }
      h1.win { color: #00ff00 }
      h1.lose { color: #ff0000 }
      #canvas {
          position: absolute;
          top: 0;
          left: 0;
          background-image: url("chasm.png");
          background-position: top left;
          background-repeat: no-repeat;
      }
    </style>
    <script>
      var canvas, ctx;
      var ballX, ballY, ballVX, ballVY, accel, playing, shark
      var THRESHOLD = 15;
      var MAX_SPEED = 400;
      var SCALE = 5;
      
      var sharkDir = true
      var sharkPos = 60
      
      var sharkMin = 60
      var sharkMax = 650
      
      function init() {
        pip.accelerometer.setPollInterval(20);

        shark = [
            document.querySelector('#shark_l'),
            document.querySelector('#shark_r')
        ]
        canvas = document.querySelector('canvas')
        ctx = canvas.getContext('2d')
        reset()
        setInterval(sample, 25)
        setInterval(loop, 25)
      }
      
      function reset() {
          playing = true
          showMessage("CROSS THE CHASM", "")
          ballX = 30
          ballY = 240
          ballVX = ballVY = 0
          accel = {x: 0, y: 0}
      }
      
      function sample() {
        accel = pip.accelerometer.read();
      }
      
      function showMessage(text, className) {
          var h = document.querySelector('h1')
          h.textContent = text
          h.className = className || ''
      }
      
      function loop() {
        if (!playing) return
          
        var val = accel
        if (Math.abs(val.x) >= THRESHOLD) {
            ballVX -= val.x * SCALE;
            if (ballVX > MAX_SPEED) ballVX = MAX_SPEED;
            if (ballVX < -MAX_SPEED) ballVX = -MAX_SPEED;
        }
        if (Math.abs(val.y) >= THRESHOLD) {
            ballVY -= val.y * SCALE;
            if (ballVY > MAX_SPEED) ballVY = MAX_SPEED;
            if (ballVY < -MAX_SPEED) ballVY = -MAX_SPEED;
        }
        ballX += ballVX * (1 / 50)
        ballY += ballVY * (1 / 50)
        
        if (sharkDir) {
            sharkPos += 4
            if (sharkPos > sharkMax) {
                sharkPos = sharkMax
                sharkDir = false
            }
        } else {
            sharkPos -= 4
            if (sharkPos < sharkMin) {
                sharkPos = sharkMin
                sharkDir = true
            }
        }
        
        if (ballX >= 760) {
            showMessage("YOU WIN", "win")
            playing = false
            setTimeout(reset, 2000)
        } else if (ballX > 40 && (ballY < 190 || ballY > 290)) {
            showMessage("GAME OVER", "lose")
            playing = false
            setTimeout(reset, 2000)
        }
        
        ctx.clearRect(0, 0, 800, 480);
        
        ctx.drawImage(sharkDir ? shark[1] : shark[0], sharkPos, 85)
        ctx.drawImage(sharkDir ? shark[0] : shark[1], sharkMin + (sharkMax - sharkPos), 320)
        
        ctx.moveTo(ballX, ballY)
        ctx.fillStyle = 'red';
        ctx.beginPath();
        ctx.arc(ballX, ballY, 25, 0, Math.PI * 2, false)
        ctx.fill()
      }
    </script>
  </head>
  <body onload='init()'>
    <img src='shark-l.png' id='shark_l'>
    <img src='shark-r.png' id='shark_r'>
    <canvas id='canvas' width='800' height='480'></canvas>
    <h1></h1>
  </body>
</html>